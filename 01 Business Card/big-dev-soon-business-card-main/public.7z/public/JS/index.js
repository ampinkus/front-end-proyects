/* This is an example JavaScript file, feel free to remove/edit it anytime */
console.log("Ver mis otros proyectos en https://portfolio-alfredo.web.app");
